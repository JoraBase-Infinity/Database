import express from 'express';
import cors from 'cors';
import { createServer as createViteServer } from 'vite';
import path from 'path';

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

// --- CONFIGURATION ---
const APPS_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbz6VAkR67yaz1c1vjYIp6ohU_h-d_sIqWZCHh5pWXn8H3g1dt-4RtVEsMidIOx3HrnB6w/exec';
const GITHUB_TOKEN = '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'; 
const GITHUB_OWNER = 'jorabase'; 
const GITHUB_REPO = 'jorabase-data'; 
// Hardcode the token to avoid issues with environment variables
const TELEGRAM_BOT_TOKEN = '8786940632:AAHNTYfESdpDBi-QEmIS1X86cc9e9DqgdJg';

function generateAccountId() {
  return 'JB-' + Math.random().toString(36).substring(2, 10).toUpperCase();
}

const githubHeaders = {
  'Authorization': `Bearer ${GITHUB_TOKEN}`,
  'User-Agent': 'JoraBase-Server',
  'Accept': 'application/vnd.github.v3+json',
  'Content-Type': 'application/json'
};

// ==========================================
// 🔥 IN-MEMORY OTP STORAGE (15 MIN EXPIRY) 🔥
// ==========================================
const otpStore = new Map<string, { code: string, expiresAt: number }>();

function setOtp(contact: string, code: string) {
  otpStore.set(contact, { code, expiresAt: Date.now() + 15 * 60 * 1000 });
}

function getOtp(contact: string) {
  const record = otpStore.get(contact);
  if (!record) return null;
  if (Date.now() > record.expiresAt) {
    otpStore.delete(contact);
    return null;
  }
  return record.code;
}

function deleteOtp(contact: string) {
  otpStore.delete(contact);
}

// ==========================================
// 🔥 THE BATCHING QUEUE SYSTEM (3 SECONDS) 🔥
// ==========================================
let gitHubQueue: any[] = [];
let isProcessingQueue = false;

function addToGitHubQueue(path: string, contentObj: any) {
  return new Promise((resolve, reject) => {
    gitHubQueue.push({ path, contentObj, resolve, reject });
    if (!isProcessingQueue) {
      isProcessingQueue = true;
      setTimeout(processGitHubQueue, 3000);
    }
  });
}

async function processGitHubQueue() {
  if (gitHubQueue.length === 0) {
    isProcessingQueue = false;
    return;
  }

  const batch = [...gitHubQueue];
  gitHubQueue = []; 

  try {
    let refRes = await fetch(`https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/git/refs/heads/main`, { headers: githubHeaders });
    let refData = await refRes.json();
    let branchName = 'main';

    if (!refRes.ok) {
      refRes = await fetch(`https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/git/refs/heads/master`, { headers: githubHeaders });
      refData = await refRes.json();
      branchName = 'master';
    }

    if (!refRes.ok || !refData.object) {
      const initRes = await fetch(`https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/contents/README.md`, {
        method: 'PUT',
        headers: githubHeaders,
        body: JSON.stringify({ message: 'Initialize JoraBase Database', content: Buffer.from('# JoraBase Database\nAuto-initialized.').toString('base64') })
      });
      if (!initRes.ok) throw new Error("Failed to auto-initialize empty repository.");
      refRes = await fetch(`https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/git/refs/heads/main`, { headers: githubHeaders });
      refData = await refRes.json();
      branchName = 'main';
    }

    const latestCommitSha = refData.object.sha;
    const commitRes = await fetch(`https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/git/commits/${latestCommitSha}`, { headers: githubHeaders });
    const commitData = await commitRes.json();
    const baseTreeSha = commitData.tree.sha;

    const tree = batch.map(item => ({
      path: item.path,
      mode: '100644',
      type: 'blob',
      content: JSON.stringify(item.contentObj, null, 2)
    }));

    const treeRes = await fetch(`https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/git/trees`, {
      method: 'POST',
      headers: githubHeaders,
      body: JSON.stringify({ base_tree: baseTreeSha, tree })
    });
    const treeData = await treeRes.json();

    if (!treeRes.ok) throw new Error(`Tree Error: ${treeData.message}`);

    const createCommitRes = await fetch(`https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/git/commits`, {
      method: 'POST',
      headers: githubHeaders,
      body: JSON.stringify({ message: `JoraBase Batch Update: Saved ${batch.length} records`, tree: treeData.sha, parents: [latestCommitSha] })
    });
    const newCommitData = await createCommitRes.json();

    await fetch(`https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/git/refs/heads/${branchName}`, {
      method: 'PATCH',
      headers: githubHeaders,
      body: JSON.stringify({ sha: newCommitData.sha })
    });

    batch.forEach(item => item.resolve(true));
  } catch (error) {
    batch.forEach(item => item.reject(error));
  } finally {
    if (gitHubQueue.length > 0) {
      setTimeout(processGitHubQueue, 3000);
    } else {
      isProcessingQueue = false;
    }
  }
}

async function getGitHubFile(path: string) {
  const url = `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/contents/${path}`;
  const response = await fetch(url, { headers: githubHeaders });
  if (!response.ok) return null;
  const data = await response.json();
  const content = decodeURIComponent(escape(atob(data.content)));
  return { content: JSON.parse(content), sha: data.sha };
}

// ==========================================
// API ENDPOINTS
// ==========================================

app.post('/api/login', async (req, res) => {
  try {
    let { contact, otp, password } = req.body;
    
    let isEmail = contact.includes('@') && contact.includes('.');
    if (!isEmail) contact = contact.replace(/[@\s]/g, '');

    const savedOtp = getOtp(contact);
    if (!savedOtp) return res.status(400).json({ success: false, error: "OTP has expired or does not exist." });
    if (savedOtp !== otp) return res.status(400).json({ success: false, error: "Invalid OTP code." });

    deleteOtp(contact);

    let safeId = contact.replace(/[@.\s+]/g, '_'); 
    
    let fileData = await getGitHubFile(`db/users/${safeId}.json`);
    if (!fileData) return res.status(400).json({ success: false, error: "Account not found. Please register." });

    if (fileData.content.isMapping) {
        safeId = fileData.content.linkedEmail.replace(/[@.\s+]/g, '_');
        fileData = await getGitHubFile(`db/users/${safeId}.json`);
        if (!fileData) return res.status(400).json({ success: false, error: "Account not found." });
    }

    if (fileData.content.password !== password) {
        return res.status(400).json({ success: false, error: "Invalid password." });
    }

    return res.json({ success: true, accountId: fileData.content.accountId });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/send-otp', async (req, res) => {
  try {
    const { email, mode } = req.body;
    
    let safeEmailId = email.replace(/[@.\s+]/g, '_');
    let existingUser = await getGitHubFile(`db/users/${safeEmailId}.json`);
    
    if (mode === 'register' && existingUser) {
      return res.status(400).json({ success: false, error: "Account with this email already exists." });
    }
    if ((mode === 'forgot' || mode === 'login') && !existingUser) {
      return res.status(400).json({ success: false, error: "No account found with this email." });
    }

    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    
    setOtp(email, otp);
    await fetch(`${APPS_SCRIPT_URL}?email=${encodeURIComponent(email)}&otp=${otp}`); 

    return res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/telegram/send-otp', async (req, res) => {
  try {
    let { telegramId, mode } = req.body; 
    telegramId = telegramId.replace(/[@\s]/g, '');

    let safeTgId = telegramId.replace(/[@.\s+]/g, '_');
    let existingTgUser = await getGitHubFile(`db/users/${safeTgId}.json`);

    if (mode === 'register' && existingTgUser) {
      return res.status(400).json({ success: false, error: "This Telegram number/username is already linked to an account." });
    }
    if ((mode === 'forgot' || mode === 'login') && !existingTgUser) {
      return res.status(400).json({ success: false, error: "No account found linked to this Telegram number/username." });
    }

    let chatIdFile = await getGitHubFile(`db/telegram/${telegramId}.json`);
    if (!chatIdFile && /^\d+$/.test(telegramId)) {
      chatIdFile = await getGitHubFile(`db/telegram/+${telegramId}.json`);
    }

    if (!chatIdFile) return res.json({ success: false, needsBotStart: true, error: "Chat ID not found. Please connect to the bot first." });

    const chatId = chatIdFile.content.chatId;
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    setOtp(telegramId, otp);

    await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, text: `🔐 Welcome to JoraBase!\n\nYour verification code is: *${otp}*\n\n_This code will expire in 15 minutes._\nDo not share this code with anyone.`, parse_mode: 'Markdown' })
    });

    return res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/verify-otp', async (req, res) => {
  try {
    let { contact, otp, userData } = req.body;
    
    let isEmail = contact.includes('@') && contact.includes('.');
    if (!isEmail) contact = contact.replace(/[@\s]/g, '');

    const savedOtp = getOtp(contact);
    if (!savedOtp) return res.status(400).json({ success: false, error: "OTP has expired or does not exist." });
    if (savedOtp !== otp) return res.status(400).json({ success: false, error: "Invalid OTP code." });

    deleteOtp(contact);

    let safeEmailId = userData.email.replace(/[@.\s+]/g, '_');
    let path = `db/users/${safeEmailId}.json`;
    
    let existingUser = await getGitHubFile(path);
    if (existingUser) return res.status(400).json({ success: false, error: "Account with this email already exists." });

    let safePhoneId = userData.phone.replace(/[@.\s+]/g, '_');
    let existingPhoneUser = await getGitHubFile(`db/users/${safePhoneId}.json`);
    if (existingPhoneUser) return res.status(400).json({ success: false, error: "Account with this phone number already exists." });

    if (!isEmail) {
        let safeTgId = contact.replace(/[@.\s+]/g, '_');
        let existingTgUser = await getGitHubFile(`db/users/${safeTgId}.json`);
        if (existingTgUser) return res.status(400).json({ success: false, error: "This Telegram number/username is already linked to an account." });
    }

    userData.accountId = generateAccountId();
    userData.createdAt = new Date().toISOString();
    
    if (!isEmail) {
        userData.telegramId = contact;
    }
    
    await addToGitHubQueue(path, userData);
    await addToGitHubQueue(`db/users/${safePhoneId}.json`, { isMapping: true, linkedEmail: userData.email });

    if (!isEmail) {
        let safeTgId = contact.replace(/[@.\s+]/g, '_');
        await addToGitHubQueue(`db/users/${safeTgId}.json`, { isMapping: true, linkedEmail: userData.email });
    }

    return res.json({ success: true, accountId: userData.accountId });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/reset-password', async (req, res) => {
  try {
    let { contact, otp, newPassword } = req.body;
    
    let isEmail = contact.includes('@') && contact.includes('.');
    if (!isEmail) contact = contact.replace(/[@\s]/g, '');

    const savedOtp = getOtp(contact);
    if (!savedOtp) return res.status(400).json({ success: false, error: "OTP has expired or does not exist." });
    if (savedOtp !== otp) return res.status(400).json({ success: false, error: "Invalid OTP code." });

    deleteOtp(contact);

    let safeId = contact.replace(/[@.\s+]/g, '_');
    let path = `db/users/${safeId}.json`;
    
    let fileData = await getGitHubFile(path);
    if (!fileData) return res.status(400).json({ success: false, error: "Account not found." });

    if (fileData.content.isMapping) {
        safeId = fileData.content.linkedEmail.replace(/[@.\s+]/g, '_');
        path = `db/users/${safeId}.json`;
        fileData = await getGitHubFile(path);
        if (!fileData) return res.status(400).json({ success: false, error: "Account not found." });
    }

    fileData.content.password = newPassword;
    await addToGitHubQueue(path, fileData.content);

    return res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/lookup-account', async (req, res) => {
  try {
    const { contact } = req.body;
    let isEmail = contact.includes('@') && contact.includes('.');
    let safeId = contact.replace(/[@.\s+]/g, '_');
    let path = `db/users/${safeId}.json`;
    
    let fileData = await getGitHubFile(path);
    if (!fileData) {
        // Try phone number lookup if not email
        if (!isEmail) {
            // Try with +880 prefix if not provided
            let phoneWithPlus = contact.startsWith('+') ? contact : '+880' + contact.replace(/^0+/, '');
            let safePhoneId = phoneWithPlus.replace(/[@.\s+]/g, '_');
            fileData = await getGitHubFile(`db/users/${safePhoneId}.json`);
        }
    }
    
    if (!fileData) return res.status(400).json({ success: false, error: "Account not found." });
    
    if (fileData.content.isMapping) {
        safeId = fileData.content.linkedEmail.replace(/[@.\s+]/g, '_');
        fileData = await getGitHubFile(`db/users/${safeId}.json`);
        if (!fileData) return res.status(400).json({ success: false, error: "Account not found." });
    }
    
    // Return masked info
    const name = fileData.content.name || '';
    const email = fileData.content.email || '';
    const phone = fileData.content.phone || '';
    
    // Mask email: keep first 2 and last part after @
    const maskedEmail = email ? email.replace(/(?<=.{2}).(?=[^@]*?@)/g, '*') : '';
    
    // Mask phone: keep first 3 and last 4
    const maskedPhone = phone ? phone.replace(/(?<=.{3}).(?=.{4})/g, '*') : '';
    
    return res.json({ success: true, account: { name, email: maskedEmail, phone: maskedPhone, rawEmail: email, rawPhone: phone } });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/telegram/set-webhook', async (req, res) => {
  try {
    const host = req.headers['x-forwarded-host'] || req.headers.host;
    const baseUrl = process.env.APP_URL || `https://${host}`;
    const url = `${baseUrl}/api/telegram/webhook`;
    const response = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/setWebhook?url=${url}`);
    const data = await response.json();
    res.json({ success: true, url, telegramResponse: data });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/telegram/webhook', async (req, res) => {
  try {
    const update = req.body;
    console.log("Received Telegram Webhook:", JSON.stringify(update, null, 2));
    
    if (update.message) {
      const chatId = update.message.chat.id;
      
      if (update.message.text && update.message.text.startsWith('/start')) {
        const username = update.message.from.username;
        console.log("Processing /start for username:", username);
        
        const sendRes = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            chat_id: chatId,
            text: `Welcome to JoraBase! 🚀\n\nTo use your phone number for verification, please click the button below to share your contact.`,
            reply_markup: { keyboard: [[{ text: "📱 Share Phone Number", request_contact: true }]], resize_keyboard: true, one_time_keyboard: true }
          })
        });
        console.log("Send message response:", sendRes.status, await sendRes.text());

        if (username) {
          addToGitHubQueue(`db/telegram/${username}.json`, { chatId: chatId.toString() }).catch(console.error);
        }
      }

      if (update.message.contact) {
        let phone = update.message.contact.phone_number;
        let phoneWithPlus = phone.startsWith('+') ? phone : '+' + phone;
        let phoneWithoutPlus = phone.replace('+', '');
        
        await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ chat_id: chatId, text: `✅ Phone number ${phoneWithPlus} linked successfully!\n\nYou can now go back to the website and request your OTP using this number.`, reply_markup: { remove_keyboard: true } })
        });

        addToGitHubQueue(`db/telegram/${phoneWithPlus}.json`, { chatId: chatId.toString() }).catch(console.error);
        addToGitHubQueue(`db/telegram/${phoneWithoutPlus}.json`, { chatId: chatId.toString() }).catch(console.error);
      }
    }
    return res.status(200).send("OK");
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// --- VITE MIDDLEWARE ---
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", async () => {
    console.log(`Server running on http://localhost:${PORT}`);
    
    // Remove webhook and start long polling for development
    try {
      await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/deleteWebhook`);
      console.log("Telegram Webhook removed. Starting long polling...");
      startTelegramPolling();
    } catch (err) {
      console.error("Failed to setup Telegram polling:", err);
    }
  });
}

// --- TELEGRAM LONG POLLING ---
let lastUpdateId = 0;
async function startTelegramPolling() {
  try {
    const res = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/getUpdates?offset=${lastUpdateId + 1}&timeout=30`);
    const data = await res.json();
    
    if (data.ok && data.result.length > 0) {
      for (const update of data.result) {
        lastUpdateId = update.update_id;
        await processTelegramUpdate(update);
      }
    }
  } catch (error) {
    console.error("Telegram polling error:", error);
  }
  
  // Continue polling
  setTimeout(startTelegramPolling, 1000);
}

async function processTelegramUpdate(update: any) {
  console.log("Received Telegram Update:", JSON.stringify(update, null, 2));
  
  if (update.message) {
    const chatId = update.message.chat.id;
    
    if (update.message.text && update.message.text.startsWith('/start')) {
      const username = update.message.from.username;
      console.log("Processing /start for username:", username);
      
      const sendRes = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: chatId,
          text: `Welcome to JoraBase! 🚀\n\nTo use your phone number for verification, please click the button below to share your contact.`,
          reply_markup: { keyboard: [[{ text: "📱 Share Phone Number", request_contact: true }]], resize_keyboard: true, one_time_keyboard: true }
        })
      });
      console.log("Send message response:", sendRes.status, await sendRes.text());

      if (username) {
        addToGitHubQueue(`db/telegram/${username}.json`, { chatId: chatId.toString() }).catch(console.error);
      }
    }

    if (update.message.contact) {
      let phone = update.message.contact.phone_number;
      let phoneWithPlus = phone.startsWith('+') ? phone : '+' + phone;
      let phoneWithoutPlus = phone.replace('+', '');
      
      await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: chatId, text: `✅ Phone number ${phoneWithPlus} linked successfully!\n\nYou can now go back to the website and request your OTP using this number.`, reply_markup: { remove_keyboard: true } })
      });

      addToGitHubQueue(`db/telegram/${phoneWithPlus}.json`, { chatId: chatId.toString() }).catch(console.error);
      addToGitHubQueue(`db/telegram/${phoneWithoutPlus}.json`, { chatId: chatId.toString() }).catch(console.error);
    }
  }
}

startServer();
