import { Hono } from 'hono';
import { cors } from 'hono/cors';

// Cloudflare Worker Environment Variables (Secrets & KV)
type Bindings = {
  GITHUB_TOKEN: string;
  TELEGRAM_BOT_TOKEN: string;
  APPS_SCRIPT_URL: string;
  JORA_KV: KVNamespace; // Cloudflare KV for storing OTPs
};

const app = new Hono<{ Bindings: Bindings }>();

// Enable CORS for all routes so your GitHub Pages frontend can connect
app.use('/api/*', cors());

const GITHUB_OWNER = 'jorabase';
const GITHUB_REPO = 'jorabase-data';

function generateAccountId() {
  return 'JB-' + Math.random().toString(36).substring(2, 10).toUpperCase();
}

function getGithubHeaders(token: string) {
  return {
    'Authorization': `Bearer ${token}`,
    'User-Agent': 'JoraBase-Cloudflare-Worker',
    'Accept': 'application/vnd.github.v3+json',
    'Content-Type': 'application/json'
  };
}

// Helper to get file from GitHub
async function getGitHubFile(env: Bindings, path: string) {
  const url = `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/contents/${path}`;
  const response = await fetch(url, { headers: getGithubHeaders(env.GITHUB_TOKEN) });
  if (!response.ok) return null;
  const data = await response.json();
  // Decode base64 content
  const content = decodeURIComponent(escape(atob(data.content.replace(/\n/g, ''))));
  return { content: JSON.parse(content), sha: data.sha };
}

// Helper to commit multiple files at once to GitHub
async function commitToGitHub(env: Bindings, files: { path: string, contentObj: any }[]) {
  const headers = getGithubHeaders(env.GITHUB_TOKEN);
  
  // 1. Get latest commit SHA
  let refRes = await fetch(`https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/git/refs/heads/main`, { headers });
  let refData = await refRes.json();
  let branchName = 'main';

  if (!refRes.ok) {
    refRes = await fetch(`https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/git/refs/heads/master`, { headers });
    refData = await refRes.json();
    branchName = 'master';
  }

  if (!refRes.ok || !refData.object) {
    // Auto-initialize if repository is empty
    await fetch(`https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/contents/README.md`, {
      method: 'PUT',
      headers,
      body: JSON.stringify({ message: 'Initialize JoraBase Database', content: btoa('# JoraBase Database') })
    });
    refRes = await fetch(`https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/git/refs/heads/main`, { headers });
    refData = await refRes.json();
    branchName = 'main';
  }

  const latestCommitSha = refData.object.sha;
  const commitRes = await fetch(`https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/git/commits/${latestCommitSha}`, { headers });
  const commitData = await commitRes.json();
  const baseTreeSha = commitData.tree.sha;

  // 2. Create new tree with all files
  const tree = files.map(item => ({
    path: item.path,
    mode: '100644',
    type: 'blob',
    content: JSON.stringify(item.contentObj, null, 2)
  }));

  const treeRes = await fetch(`https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/git/trees`, {
    method: 'POST',
    headers,
    body: JSON.stringify({ base_tree: baseTreeSha, tree })
  });
  const treeData = await treeRes.json();
  if (!treeRes.ok) throw new Error(`Tree Error: ${treeData.message}`);

  // 3. Create commit
  const createCommitRes = await fetch(`https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/git/commits`, {
    method: 'POST',
    headers,
    body: JSON.stringify({ message: `JoraBase Update: Saved ${files.length} records`, tree: treeData.sha, parents: [latestCommitSha] })
  });
  const newCommitData = await createCommitRes.json();

  // 4. Update reference (push to branch)
  await fetch(`https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/git/refs/heads/${branchName}`, {
    method: 'PATCH',
    headers,
    body: JSON.stringify({ sha: newCommitData.sha })
  });
}

// ==========================================
// DEVELOPER DASHBOARD API ENDPOINTS
// ==========================================

function generateProjectId() {
  return 'proj_' + Math.random().toString(36).substring(2, 10) + Date.now().toString(36);
}

function generateSecretKey() {
  return 'sk_live_' + Array.from(crypto.getRandomValues(new Uint8Array(32)))
    .map(b => b.toString(16).padStart(2, '0')).join('');
}

app.post('/api/projects/create', async (c) => {
  try {
    const { accountId, projectName } = await c.req.json();
    
    if (!accountId || !projectName) {
      return c.json({ success: false, error: "Account ID and Project Name are required." }, 400);
    }

    const projectId = generateProjectId();
    const secretKey = generateSecretKey();
    const createdAt = new Date().toISOString();

    const projectData = {
      projectId,
      secretKey,
      projectName,
      ownerId: accountId,
      createdAt,
      status: 'active'
    };

    // Save project metadata
    const filesToCommit = [
      { path: `db/projects/${projectId}.json`, contentObj: projectData }
    ];

    await commitToGitHub(c.env, filesToCommit);

    return c.json({ 
      success: true, 
      project: {
        projectId,
        secretKey,
        projectName,
        createdAt
      }
    });
  } catch (error: any) {
    return c.json({ success: false, error: error.message }, 500);
  }
});

// ==========================================
// AUTH API ENDPOINTS
// ==========================================

app.post('/api/login', async (c) => {
  try {
    let { contact, otp, password } = await c.req.json();
    let isEmail = contact.includes('@') && contact.includes('.');
    if (!isEmail) contact = contact.replace(/[@\s]/g, '');

    // Check OTP from Cloudflare KV
    const savedOtp = await c.env.JORA_KV.get(contact);
    if (!savedOtp) return c.json({ success: false, error: "OTP has expired or does not exist." }, 400);
    if (savedOtp !== otp) return c.json({ success: false, error: "Invalid OTP code." }, 400);

    // Delete OTP after successful verification
    await c.env.JORA_KV.delete(contact);

    let safeId = contact.replace(/[@.\s+]/g, '_');
    let fileData = await getGitHubFile(c.env, `db/users/${safeId}.json`);
    if (!fileData) return c.json({ success: false, error: "Account not found. Please register." }, 400);

    if (fileData.content.isMapping) {
      safeId = fileData.content.linkedEmail.replace(/[@.\s+]/g, '_');
      fileData = await getGitHubFile(c.env, `db/users/${safeId}.json`);
      if (!fileData) return c.json({ success: false, error: "Account not found." }, 400);
    }

    if (fileData.content.password !== password) {
      return c.json({ success: false, error: "Invalid password." }, 400);
    }

    return c.json({ success: true, accountId: fileData.content.accountId });
  } catch (error: any) {
    return c.json({ success: false, error: error.message }, 500);
  }
});

app.post('/api/send-otp', async (c) => {
  try {
    const { email, mode } = await c.req.json();
    let safeEmailId = email.replace(/[@.\s+]/g, '_');
    let existingUser = await getGitHubFile(c.env, `db/users/${safeEmailId}.json`);
    
    if (mode === 'register' && existingUser) {
      return c.json({ success: false, error: "Account with this email already exists." }, 400);
    }
    if ((mode === 'forgot' || mode === 'login') && !existingUser) {
      return c.json({ success: false, error: "No account found with this email." }, 400);
    }

    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    
    // Save OTP to Cloudflare KV (Expires in 15 minutes / 900 seconds)
    await c.env.JORA_KV.put(email, otp, { expirationTtl: 900 });

    if (c.env.APPS_SCRIPT_URL) {
      await fetch(`${c.env.APPS_SCRIPT_URL}?email=${encodeURIComponent(email)}&otp=${otp}`);
    }

    return c.json({ success: true });
  } catch (error: any) {
    return c.json({ success: false, error: error.message }, 500);
  }
});

app.post('/api/telegram/send-otp', async (c) => {
  try {
    let { telegramId, mode } = await c.req.json();
    telegramId = telegramId.replace(/[@\s]/g, '');

    let safeTgId = telegramId.replace(/[@.\s+]/g, '_');
    let existingTgUser = await getGitHubFile(c.env, `db/users/${safeTgId}.json`);

    if (mode === 'register' && existingTgUser) {
      return c.json({ success: false, error: "This Telegram number/username is already linked to an account." }, 400);
    }
    if ((mode === 'forgot' || mode === 'login') && !existingTgUser) {
      return c.json({ success: false, error: "No account found linked to this Telegram number/username." }, 400);
    }

    let chatIdFile = await getGitHubFile(c.env, `db/telegram/${telegramId}.json`);
    if (!chatIdFile && /^\d+$/.test(telegramId)) {
      chatIdFile = await getGitHubFile(c.env, `db/telegram/+${telegramId}.json`);
    }

    if (!chatIdFile) return c.json({ success: false, needsBotStart: true, error: "Chat ID not found. Please connect to the bot first." });

    const chatId = chatIdFile.content.chatId;
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    
    // Save OTP to Cloudflare KV
    await c.env.JORA_KV.put(telegramId, otp, { expirationTtl: 900 });

    await fetch(`https://api.telegram.org/bot${c.env.TELEGRAM_BOT_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, text: `🔐 Welcome to JoraBase!\n\nYour verification code is: *${otp}*\n\n_This code will expire in 15 minutes._\nDo not share this code with anyone.`, parse_mode: 'Markdown' })
    });

    return c.json({ success: true });
  } catch (error: any) {
    return c.json({ success: false, error: error.message }, 500);
  }
});

app.post('/api/verify-otp', async (c) => {
  try {
    let { contact, otp, userData } = await c.req.json();
    let isEmail = contact.includes('@') && contact.includes('.');
    if (!isEmail) contact = contact.replace(/[@\s]/g, '');

    const savedOtp = await c.env.JORA_KV.get(contact);
    if (!savedOtp) return c.json({ success: false, error: "OTP has expired or does not exist." }, 400);
    if (savedOtp !== otp) return c.json({ success: false, error: "Invalid OTP code." }, 400);

    await c.env.JORA_KV.delete(contact);

    let safeEmailId = userData.email.replace(/[@.\s+]/g, '_');
    let path = `db/users/${safeEmailId}.json`;
    
    let existingUser = await getGitHubFile(c.env, path);
    if (existingUser) return c.json({ success: false, error: "Account with this email already exists." }, 400);

    let safePhoneId = userData.phone.replace(/[@.\s+]/g, '_');
    let existingPhoneUser = await getGitHubFile(c.env, `db/users/${safePhoneId}.json`);
    if (existingPhoneUser) return c.json({ success: false, error: "Account with this phone number already exists." }, 400);

    if (!isEmail) {
      let safeTgId = contact.replace(/[@.\s+]/g, '_');
      let existingTgUser = await getGitHubFile(c.env, `db/users/${safeTgId}.json`);
      if (existingTgUser) return c.json({ success: false, error: "This Telegram number/username is already linked to an account." }, 400);
    }

    userData.accountId = generateAccountId();
    userData.createdAt = new Date().toISOString();
    if (!isEmail) userData.telegramId = contact;
    
    const filesToCommit = [
      { path, contentObj: userData },
      { path: `db/users/${safePhoneId}.json`, contentObj: { isMapping: true, linkedEmail: userData.email } }
    ];

    if (!isEmail) {
      let safeTgId = contact.replace(/[@.\s+]/g, '_');
      filesToCommit.push({ path: `db/users/${safeTgId}.json`, contentObj: { isMapping: true, linkedEmail: userData.email } });
    }

    await commitToGitHub(c.env, filesToCommit);

    return c.json({ success: true, accountId: userData.accountId });
  } catch (error: any) {
    return c.json({ success: false, error: error.message }, 500);
  }
});

app.post('/api/reset-password', async (c) => {
  try {
    let { contact, otp, newPassword } = await c.req.json();
    let isEmail = contact.includes('@') && contact.includes('.');
    if (!isEmail) contact = contact.replace(/[@\s]/g, '');

    const savedOtp = await c.env.JORA_KV.get(contact);
    if (!savedOtp) return c.json({ success: false, error: "OTP has expired or does not exist." }, 400);
    if (savedOtp !== otp) return c.json({ success: false, error: "Invalid OTP code." }, 400);

    await c.env.JORA_KV.delete(contact);

    let safeId = contact.replace(/[@.\s+]/g, '_');
    let path = `db/users/${safeId}.json`;
    
    let fileData = await getGitHubFile(c.env, path);
    if (!fileData) return c.json({ success: false, error: "Account not found." }, 400);

    if (fileData.content.isMapping) {
      safeId = fileData.content.linkedEmail.replace(/[@.\s+]/g, '_');
      path = `db/users/${safeId}.json`;
      fileData = await getGitHubFile(c.env, path);
      if (!fileData) return c.json({ success: false, error: "Account not found." }, 400);
    }

    fileData.content.password = newPassword;
    await commitToGitHub(c.env, [{ path, contentObj: fileData.content }]);

    return c.json({ success: true });
  } catch (error: any) {
    return c.json({ success: false, error: error.message }, 500);
  }
});

app.post('/api/lookup-account', async (c) => {
  try {
    const { contact } = await c.req.json();
    let isEmail = contact.includes('@') && contact.includes('.');
    let safeId = contact.replace(/[@.\s+]/g, '_');
    let path = `db/users/${safeId}.json`;
    
    let fileData = await getGitHubFile(c.env, path);
    if (!fileData) {
      if (!isEmail) {
        let phoneWithPlus = contact.startsWith('+') ? contact : '+880' + contact.replace(/^0+/, '');
        let safePhoneId = phoneWithPlus.replace(/[@.\s+]/g, '_');
        fileData = await getGitHubFile(c.env, `db/users/${safePhoneId}.json`);
      }
    }
    
    if (!fileData) return c.json({ success: false, error: "Account not found." }, 400);
    
    if (fileData.content.isMapping) {
      safeId = fileData.content.linkedEmail.replace(/[@.\s+]/g, '_');
      fileData = await getGitHubFile(c.env, `db/users/${safeId}.json`);
      if (!fileData) return c.json({ success: false, error: "Account not found." }, 400);
    }
    
    const name = fileData.content.name || '';
    const email = fileData.content.email || '';
    const phone = fileData.content.phone || '';
    
    const maskedEmail = email ? email.replace(/(?<=.{2}).(?=[^@]*?@)/g, '*') : '';
    const maskedPhone = phone ? phone.replace(/(?<=.{3}).(?=.{4})/g, '*') : '';
    
    return c.json({ success: true, account: { name, email: maskedEmail, phone: maskedPhone, rawEmail: email, rawPhone: phone } });
  } catch (error: any) {
    return c.json({ success: false, error: error.message }, 500);
  }
});

// Telegram Webhook for Cloudflare Worker
app.get('/api/telegram/set-webhook', async (c) => {
  try {
    const url = new URL(c.req.url);
    const webhookUrl = `${url.origin}/api/telegram/webhook`;
    const response = await fetch(`https://api.telegram.org/bot${c.env.TELEGRAM_BOT_TOKEN}/setWebhook?url=${webhookUrl}`);
    const data = await response.json();
    return c.json({ success: true, url: webhookUrl, telegramResponse: data });
  } catch (error: any) {
    return c.json({ success: false, error: error.message }, 500);
  }
});

app.post('/api/telegram/webhook', async (c) => {
  try {
    const update = await c.req.json();
    
    if (update.message) {
      const chatId = update.message.chat.id;
      
      if (update.message.text && update.message.text.startsWith('/start')) {
        const username = update.message.from.username;
        
        await fetch(`https://api.telegram.org/bot${c.env.TELEGRAM_BOT_TOKEN}/sendMessage`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            chat_id: chatId,
            text: `Welcome to JoraBase! 🚀\n\nTo use your phone number for verification, please click the button below to share your contact.`,
            reply_markup: { keyboard: [[{ text: "📱 Share Phone Number", request_contact: true }]], resize_keyboard: true, one_time_keyboard: true }
          })
        });

        if (username) {
          // Use waitUntil for background tasks in Cloudflare Workers
          c.executionCtx.waitUntil(commitToGitHub(c.env, [{ path: `db/telegram/${username}.json`, contentObj: { chatId: chatId.toString() } }]));
        }
      }

      if (update.message.contact) {
        let phone = update.message.contact.phone_number;
        let phoneWithPlus = phone.startsWith('+') ? phone : '+' + phone;
        let phoneWithoutPlus = phone.replace('+', '');
        
        await fetch(`https://api.telegram.org/bot${c.env.TELEGRAM_BOT_TOKEN}/sendMessage`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ chat_id: chatId, text: `✅ Phone number ${phoneWithPlus} linked successfully!\n\nYou can now go back to the website and request your OTP using this number.`, reply_markup: { remove_keyboard: true } })
        });

        c.executionCtx.waitUntil(commitToGitHub(c.env, [
          { path: `db/telegram/${phoneWithPlus}.json`, contentObj: { chatId: chatId.toString() } },
          { path: `db/telegram/${phoneWithoutPlus}.json`, contentObj: { chatId: chatId.toString() } }
        ]));
      }
    }
    return c.text("OK");
  } catch (error: any) {
    return c.json({ success: false, error: error.message }, 500);
  }
});

export default app;
